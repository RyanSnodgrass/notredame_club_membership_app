require 'test_helper'

class ClubsHelperTest < ActionView::TestCase
end
